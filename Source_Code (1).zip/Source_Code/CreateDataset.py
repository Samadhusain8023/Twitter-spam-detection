import os
import csv
import tweepy    #this will give an error if tweepy is not installed properly
from tweepy import OAuthHandler
import json
import re
import sys
from textblob import TextBlob

#provide your access details below 
consumer_key = "HyvTGPZOElNuzFcvkWG2F2FQv"
consumer_secret = "mIsUnLgWVCVLUrbIbvP5QnzHjCsvMhKVCnmM7A2sbWeTNnMhP8"
access_token = "964365971887501312-TlreD3J7RkMshqx8qYbNIIZ6kBjQUBO"
access_token_secret = "NPfG72WkzFyEyd5DwcX9fDeH6rrMbAeqYkLBE6wID7R7m"
 
auth = OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
 
api = tweepy.API(auth)    
    
from tweepy import Stream
from tweepy.streaming import StreamListener


i=0
class MyListener(StreamListener):
    def on_data(self, data):
        global i
        try:
            with open('twitter.json', 'a') as f:  #change location here
            	i=i+1
            	print(i)
            	f.write(data)
            	if i>20:
            		sys.exit(1)
            		return False
            	else:
            		return True
        except BaseException as e:
            print("Error on_data: %s" % str(e))
            return False
 
    def on_error(self, status):
        print(status)
        return False

def clean_tweet(tweet):
	return ' '.join(re.sub("(@[A-Za-z0-9]+)|([^0-9A-Za-z \t])|(\w+:\/\/\S+)", " ", tweet).split())



def process():
	twitter_stream = Stream(auth, MyListener())
	#change the keyword here
	twitter_stream.filter(track=['#Apple'])
	
	with open('twitter.json') as in_file, open('data.csv', 'w',newline='') as out_file:
		writer = csv.writer(out_file, delimiter=',')
		writer.writerow(["text","id","screen_name","statuses_count","followers_count","friends_count","favourites_count","listed_count","url","lang","time_zone","location","default_profile","default_profile_image","geo_enabled","profile_image_url","profile_background_image_url_https","profile_text_color","profile_image_url_https","profile_sidebar_border_color","profile_background_tile","profile_sidebar_fill_color","profile_background_image_url","profile_background_color","profile_link_color","utc_offset","is_translator","follow_request_sent","protected","verified","notifications","description","contributors_enabled","following","created_at"])
		
		#
		for line in in_file:
			if line.strip() == "" :
				continue
			else:
				tweet = json.loads(line)
				d=str(tweet['user']['description'])
				description=None
				if d != "None":
					description=clean_tweet(tweet['user']['description'])
	
				l=str(tweet['user']['location'])
				loc=None
				if l != "None":
					loc=clean_tweet(tweet['user']['location'])
		

				tweet['text']=clean_tweet(tweet['text'])
				print(tweet['text'])
				row = (tweet['text'],tweet['id'],tweet['user']['screen_name'],tweet['user']['statuses_count'],tweet['user']['followers_count'],tweet['user']['friends_count'],tweet['user']['favourites_count'],tweet['user']['listed_count'],tweet['user']['url'],tweet['user']['lang'],tweet['user']['time_zone'],loc,tweet['user']['default_profile'],tweet['user']['default_profile_image'],tweet['user']['geo_enabled'],tweet['user']['profile_image_url'],tweet['user']['profile_background_image_url_https'],tweet['user']['profile_text_color'],tweet['user']['profile_image_url_https'],tweet['user']['profile_sidebar_border_color'],tweet['user']['profile_background_tile'],tweet['user']['profile_sidebar_fill_color'],tweet['user']['profile_background_image_url'],tweet['user']['profile_background_color'],tweet['user']['profile_link_color'],tweet['user']['utc_offset'],tweet['user']['is_translator'],tweet['user']['follow_request_sent'],tweet['user']['protected'],tweet['user']['verified'],tweet['user']['notifications'],description,tweet['user']['contributors_enabled'],tweet['user']['following'],tweet['user']['created_at'])
				writer.writerow(row)
	out_file.close()

#process()		

    