import pandas as pd
import numpy as np
from statistics import stdev 


def process(path):
	df=pd.read_csv(path)
	df1=df[(df["followers_count"]>30) & (df["statuses_count"]>50) & (df["listed_count"]>0)]
	v="Geniue"
	df1["Status"]=[v for _ in range(len(df1))]

	df2 = df.drop(df1.index, axis=0)
	v="Fake"
	df2["Status"]=[v for _ in range(len(df2))]

	frames=[df1,df2]
	result=pd.concat(frames)
	print(result)
	result.to_csv("dataset.csv",index=False)


	df=pd.read_csv("dataset.csv",usecols=["id","statuses_count","followers_count","friends_count","favourites_count","listed_count","default_profile","default_profile_image","geo_enabled","profile_background_tile","is_translator","protected","verified","contributors_enabled","Status"])
	print(df)

	df['default_profile'] = (df['default_profile']).astype(int)
	print(df['default_profile'])
	df['default_profile_image'] = (df['default_profile_image']).astype(int)
	print(df['default_profile_image'])


	df['geo_enabled'] = (df['geo_enabled']).astype(int)
	print(df['geo_enabled'])

	
	df['profile_background_tile'] = (df['profile_background_tile']).astype(int)
	print(df['profile_background_tile'])
	
	df['is_translator'] = (df['is_translator']).astype(int)
	print(df['is_translator'])
	
	
	df['protected'] = (df['protected']).astype(int)
	print(df['protected'])
	

	df['verified'] = (df['verified']).astype(int)
	print(df['verified'])

	
	df['contributors_enabled'] = (df['contributors_enabled']).astype(int)
	print(df['contributors_enabled'])

	
	df.loc[ df['Status'] =="Geniue","Status"]=0
	df.loc[ df['Status'] =="Fake","Status"]=1
	
	print(df['Status'])
	

	
	
	mean=df["friends_count"].mean(axis = 0) 
	std=stdev(df["friends_count"])
	
	print(mean)
	print(std)
	for i in range(0,len(df)):
		#print(mean-df["friends_count"].iloc[i])
		#m=mean-df["friends_count"].iloc[i]
		#print(m)
		#s=m/std
		#print(s)
		df["friends_count"].iloc[i]=abs(round((mean-df["friends_count"].iloc[i])/std))
	
	df.to_csv("finaldata.csv")
